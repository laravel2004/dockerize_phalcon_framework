<script src="<?= $this->url->get('assets/static/js/components/dark.js') ?>"></script>
<script src="<?= $this->url->get('assets/extensions/perfect-scrollbar/perfect-scrollbar.min.js') ?>"></script>
<script src="<?= $this->url->get('assets/compiled/js/app.js') ?>"></script>
