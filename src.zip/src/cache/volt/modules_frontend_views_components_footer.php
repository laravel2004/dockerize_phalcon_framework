<footer>
    <div class="footer clearfix mb-0 text-muted">
        <div class="float-start">
            <p><script>document.write(new Date().getFullYear())</script> &copy; PT Rejoso Manis Indo - MITR PHOL GROUP</p>
        </div>
    </div>
</footer>
