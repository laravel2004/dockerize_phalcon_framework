<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= $title ?></title>
<link rel="stylesheet" href="<?= $this->url->get('assets/compiled/css/app.css') ?>">
<link rel="stylesheet" href="<?= $this->url->get('assets/compiled/css/app-dark.css') ?>">
